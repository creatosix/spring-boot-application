package com.example.conferenceConsumer;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class ConferenceConsumerApplicationTests {

	@Test
	void contextLoads() {
	}

}
